# Contributing

👍🎉 First off, thanks for taking the time to contribute! 🎉👍

Contributing is easy , just please 

- make pull request on `v4` branch
- test your changes
- describe your changes in pull request 
